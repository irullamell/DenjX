(async () => {
    require("./config");
    const {
        default: makeWASocket,
        useMultiFileAuthState,
        makeInMemoryStore,
        makeCacheableSignalKeyStore,
        DisconnectReason,
        fetchLatestBaileysVersion,
        jidNormalizedUser
    } = require("baileys");
    const WebSocket = require("ws");
    const path = require("path");
    const pino = require("pino");
    const { Boom } = require("@hapi/boom");
    const fs = require("fs");
    const CFonts = require('cfonts');
    const chokidar = require("chokidar");
    const readline = require("readline");
    const NodeCache = require("node-cache");
    const yargs = require("yargs/yargs");
    const cp = require("child_process");
    const { promisify } = require("util");
    const exec = promisify(cp.exec).bind(cp);
    const _ = require("lodash");
    const syntaxerror = require("syntax-error");
    const os = require("os");
    const simple = require("./lib/simple.js");
    const { randomBytes } = require("crypto");
    const moment = require("moment-timezone");
    const chalk = require("chalk");
    const readdir = promisify(fs.readdir);
    const stat = promisify(fs.stat);
    
    // Create folder if it doesn't exist
    function createFolderIfNotExists(folderPath) {
        if (!fs.existsSync(folderPath)) {
            fs.mkdirSync(folderPath, { recursive: true });
            console.log(chalk.green.bold(`Created folder: ${folderPath}`));
        }
    }

    // Create required folders
    function createRequiredFolders() {
        // Create tmp folder
        const tmpFolderPath = path.join(__dirname, "tmp");
        createFolderIfNotExists(tmpFolderPath);
        
        // Create database folder
        const databaseFolderPath = path.join(__dirname, "database");
        createFolderIfNotExists(databaseFolderPath);
    }

    // Call the function to create required folders
    createRequiredFolders();
    
    // Generate random ID function
    const randomID = (length) =>
        randomBytes(Math.ceil(length * 0.5))
            .toString("hex")
            .slice(0, length);
    
    // Parse command line arguments
    global.opts = new Object(
        yargs(process.argv.slice(2)).exitProcess(false).parse()
    );
    
    // Set global prefix for commands
    global.prefix = new RegExp(
        "^[" +
        (
            opts["prefix"] ||
            "/!#$%+£¢€¥^°=¶∆×÷π√✓©®:;?&.-"
        ).replace(/[|\\{}()[\]^$+*?.\-\^]/g, "\\$&") +
        "]"
    );
    
    // Dynamic module loading function
    async function load(module) {
        var module_ = await import(`${module}?id=${Date.now()}`);
        var result = module_ && 'default' in module_ ? module_.default : module_;
        return result;
    }
    
    // Database setup
    const dbFilePath = path.join(__dirname, './database/database.json'); 
    const defaultDatabase = {
        users: {},
        chats: {},
        stats: {},
        msgs: {},
        sticker: {},
        settings: {},
        respon: {},
    };
    
    // Database methods
    global.db = {
        READ: false, 
        data: null,  
        async read() {
            try {
                const data = fs.readFileSync(dbFilePath, 'utf-8');
                this.data = JSON.parse(data); 
                return this.data;
            } catch (error) {
                console.error('Error reading database file:', error);
                this.data = null;
                return null;
            }
        },
        async write(data) {
            try {
                fs.writeFileSync(dbFilePath, JSON.stringify(data, null, 2)); 
                return true;
            } catch (error) {
                console.error('Error writing database file:', error);
                return false;
            }
        }
    };
    
    // Load database
    global.loadDatabase = async() => {
        if (!db.READ) {
            setInterval(async () => {
                if (db.data) await db.write(db.data);
            }, 2000);
            db.READ = true;
        }
        
        if (db.data !== null) return;
        
        await db.read();
        if (db.data === null) {
            console.warn('Initializing database with default values.');
            db.data = defaultDatabase;
        }
        
        db.READ = false;
        db.data = {
            ...defaultDatabase,
            ...(db.data || {}),
        };
        db.chain = _.chain(db.data);
    };
    
    // Initialize database
    await loadDatabase();
    
    // Create in-memory store
    global.store = makeInMemoryStore({
        logger: pino().child({
            level: "silent",
            stream: "store",
        }),
    });
    
    // Set auth folder
    global.authFolder = `session`;
    
    // Logger setup
    const logger = pino({ 
        timestamp: () => `,"time":"${new Date().toJSON()}"` 
    }).child({ class: 'Denji' });
    logger.level = 'fatal';
    
    // Auth state setup
    const {
        state,
        saveState,
        saveCreds
    } = await useMultiFileAuthState(authFolder);
    
    // Message retry setup
    const msgRetryCounterCache = new NodeCache();
    
    // Get Baileys version
    const { version } = await fetchLatestBaileysVersion();
    
    // Create readline interface
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout,
    });
    
    // Question prompt function
    const question = (texto) => new Promise((resolver) => rl.question(texto, resolver));
    
    // Load store data
    store.readFromFile(path.join(process.cwd(), `${authFolder}/store.json`));
    
    // Connection options
    const connectionOptions = {
        printQRInTerminal: false,
        syncFullHistory: true,
        markOnlineOnConnect: true,
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 0,
        keepAliveIntervalMs: 10000,
        generateHighQualityLinkPreview: true,
        patchMessageBeforeSending: (message) => {
            const requiresPatch = !!(
                message.buttonsMessage ||
                message.templateMessage ||
                message.listMessage
            );
            if (requiresPatch) {
                message = {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadataVersion: 2,
                                deviceListMetadata: {},
                            },
                            ...message,
                        },
                    },
                };
            }
            return message;
        },
        version,
        browser: ["Ubuntu", "Safari", "20.0.04"],
        logger: pino({ level: "fatal" }),
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(
                state.keys,
                pino().child({
                    level: "silent",
                    stream: "store",
                })
            ),
        },
        getMessage: async (key) => {
            if (store) {
                const msg = await store.loadMessage(key.remoteJid, key.id);
                return msg?.message || undefined;
            }
            return {
                conversation: "Denji",
            };
        },
        msgRetryCounterCache,
        defaultQueryTimeoutMs: undefined,
    };
    
    // Create WhatsApp socket connection
    global.conn = simple.makeWASocket(connectionOptions);
    store.bind(conn.ev);
    
    // Check if pairing is required
    const isPairing = !conn.authState?.creds?.registered;
    
    if (isPairing) {
        // Display welcome message
        CFonts.say('WELCOME', {
            font: 'tiny',
            align: 'center',
        });
        
        CFonts.say('Powered By Denji', {
            colors: ['system'],
            font: 'console',
            align: 'center',
        });
        
        // Display OS information
        console.log(chalk.white.bold(`Operating System Information:
- Platform: ${os.platform()}
- Release: ${os.release()}
- Architecture: ${os.arch()}
- Hostname: ${os.hostname()}
- Total Memory: ${(os.totalmem() / 1024 / 1024).toFixed(2)} MB
- Free Memory: ${(os.freemem() / 1024 / 1024).toFixed(2)} MB
- Uptime: ${os.uptime()} seconds`));
        
        // Get phone number and pairing code
        console.log(chalk.red.bold("[ ! ]") + chalk.cyan.bold(` Please enter your WhatsApp number, for example +628xxxx\n`));
        const phoneNumber = await question(chalk.green.bold("Your Number : "));
        const code = await conn.requestPairingCode(phoneNumber);
        console.log(`${chalk.green.bold("- Your Pairing Code : ")} ${chalk.yellow.bold(code)}\n\n`);
    }
    
    // Connection update handler
    async function connectionUpdate(update) {
        const {
            connection,
            lastDisconnect,
            isNewLogin
        } = update;
        
        global.stopped = connection;
        
        if (isNewLogin) conn.isInit = true;
        
        if (connection === "open") {
            console.log(
                chalk.yellow.bold(
                    `[ Success ] Connected to WhatsApp: ${JSON.stringify(conn.user, null, 2)}`,
                ),
            );
        }
        
        if (connection === "close") {
            const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
            
            if (reason === DisconnectReason.badSession) {
                conn.logger.error(`Bad Session! Delete ${global.authFolder} and reconnect`);
                await reloadHandler(true);
            } else if (reason === DisconnectReason.connectionClosed) {
                conn.logger.warn(`Connection closed, reconnecting...`);
                await reloadHandler(true);
            } else if (reason === DisconnectReason.connectionLost) {
                conn.logger.warn(`Connection lost, reconnecting...`);
                await reloadHandler(true);
            } else if (reason === DisconnectReason.connectionReplaced) {
                conn.logger.error(`Connection replaced`);
                await reloadHandler(true);
            } else if (reason === DisconnectReason.loggedOut) {
                conn.logger.error(`Logged out, please delete & recreate your session`);
                await reloadHandler(true);
            } else if (reason === DisconnectReason.restartRequired) {
                conn.logger.info(`Restart required, please wait...`);
                await reloadHandler(true);
            } else if (reason === DisconnectReason.timedOut) {
                conn.logger.warn(`Connection timed out, reconnecting...`);
                await reloadHandler(true);
            } else {
                conn.logger.warn(`Connection closed: ${reason || ""} - ${connection || ""}`);
                await reloadHandler(true);
            }
        }
    }
    
    // Error handling
    process.on("uncaughtException", (err) => {
        console.error('Uncaught Exception:', err);
    });
    
    // Initialize handler
    let isInit = true;
    let handler = require("./handler");
    
    // Reload handler function
    global.reloadHandler = async function(restartConn) {
        try {
            const Handler = require("./handler");
            if (Object.keys(Handler || {}).length) handler = Handler;
            
            if (restartConn) {
                try {
                    conn.ws.close();
                } catch (e) {
                    console.error("Error closing connection:", e);
                }
                
                conn = {
                    ...conn,
                    ...simple.makeWASocket(connectionOptions),
                };
            }
            
            if (!isInit) {
                conn.ev.off("messages.upsert", conn.handler);
                conn.ev.off("group-participants.update", conn.onParticipantsUpdate);
                conn.ev.off("connection.update", conn.connectionUpdate);
                conn.ev.off("creds.update", conn.credsUpdate);
            }
            
            // Set default messages
            conn.welcome = "Welcome to *@subject* @user\nSemoga betah Dan jangan lupa baca deskripsi\n@desc";
            conn.bye = "Goodbye @user,\nSemoga tenang di alam sana.";
            conn.spromote = "@user telah naik jabatan";
            conn.sdemote = "@user telah turun jabatan🗿";
            
            // Bind handlers
            conn.handler = handler.handler.bind(conn);
            conn.onParticipantsUpdate = handler.participantsUpdate.bind(conn);
            conn.connectionUpdate = connectionUpdate.bind(conn);
            conn.credsUpdate = saveCreds.bind(conn);
            
            // Register event listeners
            conn.ev.on("messages.upsert", conn.handler);
            conn.ev.on("group-participants.update", conn.onParticipantsUpdate);
            conn.ev.on("connection.update", conn.connectionUpdate);
            conn.ev.on("creds.update", conn.credsUpdate);
            
            // Group updates
            conn.ev.on('groups.update', updates => {
                for (const update of updates) {
                    const id = update.id;
                    if (store.groupMetadata[id]) {
                        store.groupMetadata[id] = { ...(store.groupMetadata[id] || {}), ...(update || {}) };
                    }
                }
            });
            
            isInit = false;
            return true;
        } catch (e) {
            console.error("Error in reloadHandler:", e);
            return false;
        }
    };
    
    // Initialize plugins
    global.plugins = {};
    
    // Scan directories function
    let Scandir = async (dir) => {
        let subdirs = await readdir(dir);
        let files = await Promise.all(subdirs.map(async (subdir) => {
            let res = path.resolve(dir, subdir);
            return (await stat(res)).isDirectory() ? Scandir(res) : res;
        }));
        return files.reduce((a, f) => a.concat(f), []);
    };
    
    // Load plugins
    try {
        let files = await Scandir("./plugins");
        let plugins = {};
        
        for (let filename of files.map(a => a.replace(process.cwd(), ""))) {
            try {
                plugins[filename] = require(path.join(process.cwd(), filename));
            } catch (e) {
                console.log(chalk.red.bold(`Error loading plugin ${filename}:`, e));
                delete plugins[filename];
            }
        }
        
        // Watch for plugin changes
        const watcher = chokidar.watch(path.resolve("./plugins"), {
            persistent: true,
            ignoreInitial: true
        });
        
        watcher
            .on('add', async(filename) => {
                console.log(chalk.yellow.bold("[ New ] Detected New Plugin: " + filename.replace(process.cwd(), "")));
                try {
                    plugins[filename.replace(process.cwd(), "")] = require(filename);
                } catch (e) {
                    console.error(`Error loading new plugin ${filename}:`, e);
                }
            })
            .on('change', async(filename) => {
                try {
                    if (require.cache[filename]) {
                        delete require.cache[filename];
                    }
                    
                    let err = syntaxerror(fs.readFileSync(filename), filename.replace(process.cwd(), ""));
                    if (err) {
                        conn.logger.error(`Syntax error in '${filename}':\n${err}`);
                    } else {
                        plugins[filename.replace(process.cwd(), "")] = require(filename);
                        console.log(chalk.yellow.bold("[ Change ] Updated plugin: " + filename.replace(process.cwd(), "")));
                    }
                } catch (e) {
                    console.error(`Error updating plugin ${filename}:`, e);
                }
            })
            .on('unlink', (filename) => {
                console.log(chalk.yellow.bold("[ Delete ] Removed plugin: " + filename.replace(process.cwd(), "")));
                delete plugins[filename.replace(process.cwd(), "")];
            });
        
        // Sort plugins and set globally
        plugins = Object.fromEntries(Object.entries(plugins).sort(([a], [b]) => a.localeCompare(b)));   
        global.plugins = plugins;
        console.log(chalk.blue.bold(`[ Success ] Loaded ${Object.keys(plugins).length} plugins`));
    } catch (e) {
        console.error("Error loading plugins:", e);
    }
    
    // Periodically save store
    setInterval(async () => {
        try {
            store.writeToFile(path.join(process.cwd(), `${global.authFolder}/store.json`));
        } catch (e) {
            console.error("Error saving store data:", e);
        }
    }, 10 * 1000);
    
    // Initialize handler
    await reloadHandler();
    
    // Utility function for random selection
    global.pickRandom = function(list) {
        return list[Math.floor(Math.random() * list.length)];
    };
})();