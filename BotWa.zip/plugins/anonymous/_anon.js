const fs = require('fs')
const path = require('path')

// Path ke database - sesuaikan jika perlu
const dbPath = path.join(__dirname, '../../database/anonymous.json')

// Mendapatkan database
function getDB() {
   try {
      if (!fs.existsSync(dbPath)) {
         return {
            rooms: {},
            userGender: {},
            filters: {}
         }
      }
      return JSON.parse(fs.readFileSync(dbPath, 'utf-8'))
   } catch (error) {
      console.error('Error reading database:', error)
      return {
         rooms: {},
         userGender: {},
         filters: {}
      }
   }
}

// Menyimpan database
function saveDB(db) {
   fs.writeFileSync(dbPath, JSON.stringify(db, null, 2))
}

module.exports = {
   async before(m, { conn }) {
      // Hanya chat pribadi yang diproses
      if (!m.chat.endsWith('@s.whatsapp.net')) return !0
      
      let db = getDB()
      let now = Date.now()

      // Periksa semua room untuk timeout
      for (let [roomId, room] of Object.entries(db.rooms)) {
         if (room.state === 'CHATTING' && room.lastActivity && now - room.lastActivity > 86400000) {
            try {
               await conn.sendMessage(room.a, {
                  text: '⏰ Obrolan anonim telah berakhir karena tidak ada aktivitas selama 24 jam.'
               })
               await conn.sendMessage(room.b, {
                  text: '⏰ Obrolan anonim telah berakhir karena tidak ada aktivitas selama 24 jam.'
               })
            } catch (e) {
               console.error('Gagal mengirim pesan timeout:', e)
            }
            delete db.rooms[roomId]
            saveDB(db)
         }
      }

      // Temukan room aktif untuk user ini
      let room = Object.values(db.rooms).find(room =>
         (room.a === m.sender || room.b === m.sender) &&
         room.state === 'CHATTING'
      )

      if (room) {
         // Perbarui aktivitas terakhir
         room.lastActivity = now
         saveDB(db)

         // Lewati perintah tertentu
         if (/^.*(next|leave|start|skip|stop|search|setgender|filter)/i.test(m.text)) return

         let other = room.a === m.sender ? room.b : room.a
         if (other) {
            await m.copyNForward(other, true, m.quoted && m.quoted.fromMe ? {
               contextInfo: {
                  ...m.msg.contextInfo,
                  forwardingScore: 1,
                  isForwarded: true,
                  participant: other
               }
            } : {})
         }
      }

      return !0
   }
}
