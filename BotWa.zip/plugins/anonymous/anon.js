const fs = require('fs')
const path = require('path')

// Database file path
const dbPath = path.join(__dirname, '../../database/anonymous.json')

// Initialize database
function initDB() {
   try {
      if (!fs.existsSync(dbPath)) {
         const dir = path.dirname(dbPath)
         if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true })
         }
         fs.writeFileSync(dbPath, JSON.stringify({
            rooms: {},
            userGender: {},
            filters: {},
            matchHistory: {} // Added to track match history
         }, null, 2))
      }
      return JSON.parse(fs.readFileSync(dbPath, 'utf-8'))
   } catch (error) {
      console.error('Error initializing database:', error)
      return {
         rooms: {},
         userGender: {},
         filters: {},
         matchHistory: {}
      }
   }
}

// Save database
function saveDB(data) {
   try {
      fs.writeFileSync(dbPath, JSON.stringify(data, null, 2))
   } catch (error) {
      console.error('Error saving database:', error)
   }
}

// Get database
function getDB() {
   try {
      const db = JSON.parse(fs.readFileSync(dbPath, 'utf-8'))
      // Ensure matchHistory exists in existing databases
      if (!db.matchHistory) db.matchHistory = {}
      return db
   } catch (error) {
      console.error('Error reading database:', error)
      return initDB()
   }
}

// Check if users can match (3-hour cooldown)
function canMatch(user1, user2, matchHistory) {
   const key1 = `${user1}_${user2}`
   const key2 = `${user2}_${user1}`
   const now = Date.now()
   const threeHours = 3 * 60 * 60 * 1000 // 3 hours in milliseconds
   
   // Check both possible keys
   if (matchHistory[key1] && (now - matchHistory[key1]) < threeHours) {
      return false
   }
   if (matchHistory[key2] && (now - matchHistory[key2]) < threeHours) {
      return false
   }
   
   return true
}

// Record a match between two users
function recordMatch(user1, user2, matchHistory) {
   const key = `${user1}_${user2}`
   matchHistory[key] = Date.now()
   
   // Clean up old entries (older than 3 hours)
   const threeHours = 3 * 60 * 60 * 1000
   const now = Date.now()
   
   for (const [key, timestamp] of Object.entries(matchHistory)) {
      if (now - timestamp > threeHours) {
         delete matchHistory[key]
      }
   }
}

// Calculate statistics
function calculateStats(db) {
   const stats = {
      totalRooms: 0,
      activeChats: 0,
      waitingUsers: 0,
      totalUsers: 0,
      maleUsers: 0,
      femaleUsers: 0,
      averageWaitTime: 0,
      totalMatches: 0,
      recentMatches: 0,
      activeMales: 0,
      activeFemales: 0,
      waitingMales: 0,
      waitingFemales: 0
   }
   
   // Count rooms and their states
   const rooms = Object.values(db.rooms)
   stats.totalRooms = rooms.length
   
   const now = Date.now()
   let totalWaitTime = 0
   let waitingCount = 0
   
   rooms.forEach(room => {
      if (room.state === 'CHATTING') {
         stats.activeChats++
      } else if (room.state === 'WAITING') {
         stats.waitingUsers++
         const waitTime = now - new Date(room.createdAt).getTime()
         totalWaitTime += waitTime
         waitingCount++
         
         // Gender breakdown for waiting users
         const gender = db.userGender[room.a]
         if (gender === 'male') stats.waitingMales++
         else if (gender === 'female') stats.waitingFemales++
      }
   })
   
   // Calculate average wait time
   if (waitingCount > 0) {
      stats.averageWaitTime = Math.round(totalWaitTime / waitingCount / 1000) // in seconds
   }
   
   // Count gender distribution
   Object.entries(db.userGender).forEach(([user, gender]) => {
      stats.totalUsers++
      if (gender === 'male') stats.maleUsers++
      else if (gender === 'female') stats.femaleUsers++
   })
   
   // Count matches from match history
   const oneHourAgo = now - (60 * 60 * 1000)
   Object.entries(db.matchHistory).forEach(([pair, timestamp]) => {
      stats.totalMatches++
      if (timestamp > oneHourAgo) {
         stats.recentMatches++
      }
   })
   
   // Active users by gender
   const activeUsers = new Set()
   rooms.forEach(room => {
      if (room.state === 'CHATTING') {
         activeUsers.add(room.a)
         activeUsers.add(room.b)
      }
   })
   
   activeUsers.forEach(user => {
      const gender = db.userGender[user]
      if (gender === 'male') stats.activeMales++
      else if (gender === 'female') stats.activeFemales++
   })
   
   return stats
}

async function handler(m, { command, usedPrefix, args }) {
   command = command.toLowerCase()
   
   // Initialize database if needed
   let db = getDB()
   
   switch (command) {
      case 'status':
      case 'statistic':
      case 'stats': {
         const stats = calculateStats(db)
         
         let statusMessage = `*🔄 Anonymous Chat Status*\n\n`
         statusMessage += `📊 *General Statistics*\n`
         statusMessage += `• Total Rooms: ${stats.totalRooms}\n`
         statusMessage += `• Active Chats: ${stats.activeChats}\n`
         statusMessage += `• Waiting Users: ${stats.waitingUsers}\n`
         statusMessage += `• Average Wait Time: ${stats.averageWaitTime}s\n\n`
         
         statusMessage += `👥 *User Distribution*\n`
         statusMessage += `• Total Users: ${stats.totalUsers}\n`
         statusMessage += `• Male Users: ${stats.maleUsers} (${stats.totalUsers > 0 ? Math.round(stats.maleUsers/stats.totalUsers*100) : 0}%)\n`
         statusMessage += `• Female Users: ${stats.femaleUsers} (${stats.totalUsers > 0 ? Math.round(stats.femaleUsers/stats.totalUsers*100) : 0}%)\n\n`
         
         statusMessage += `🗨️ *Active Status*\n`
         statusMessage += `• Active Males: ${stats.activeMales}\n`
         statusMessage += `• Active Females: ${stats.activeFemales}\n`
         statusMessage += `• Waiting Males: ${stats.waitingMales}\n`
         statusMessage += `• Waiting Females: ${stats.waitingFemales}\n\n`
         
         statusMessage += `💬 *Match History*\n`
         statusMessage += `• Total Matches: ${stats.totalMatches}\n`
         statusMessage += `• Recent Matches (1hr): ${stats.recentMatches}\n`
         
         if (stats.totalRooms === 0) {
            statusMessage += `\n_No active sessions at the moment_`
         }
         
         return m.reply(statusMessage)
      }
      
      case 'setgender': {
         const gender = args[0]?.toLowerCase()
         if (!gender || !['male', 'female'].includes(gender)) {
            return m.reply(`*Please specify your gender!*\n\nUsage: ${usedPrefix}setgender <male/female>\n\nExample: ${usedPrefix}setgender male`)
         }
         
         // Update database
         db.userGender[m.sender] = gender
         saveDB(db)
         
         return m.reply(`*Gender set to ${gender}*\n\nYou can now search for partners using ${usedPrefix}start`)
      }
      
      case 'next':
      case 'skip': {
         // Find room from database
         let roomId = Object.keys(db.rooms).find(id => {
            const room = db.rooms[id]
            return room.a === m.sender || room.b === m.sender
         })
         
         if (!roomId) {
            await this.reply(m.chat, `*You are not in anonymous chat!*\nSend ${usedPrefix}start to start anonymous chat.`, m)
            throw 0
         }
         
         let room = db.rooms[roomId]
         this.reply(m.chat, `*You have skipped the chat.*`, m)
         
         let other = room.a === m.sender ? room.b : room.a
         if (other) this.reply(other, `*Your partner has skipped the chat.*\nType ${usedPrefix}start to find a new partner.`, null)
         
         // Record the match for cooldown (only if they were actually connected)
         if (room.state === 'CHATTING' && other) {
            recordMatch(m.sender, other, db.matchHistory)
         }
         
         // Remove room from database
         delete db.rooms[roomId]
         
         saveDB(db)
         break
      }
      
      case 'stop': {
         // Find room from database
         let roomId = Object.keys(db.rooms).find(id => {
            const room = db.rooms[id]
            return room.a === m.sender || room.b === m.sender
         })
         
         if (!roomId) {
            await this.reply(m.chat, `*You are not in anonymous chat!*\nSend ${usedPrefix}start to start anonymous chat.`, m)
            throw 0
         }
         
         let room = db.rooms[roomId]
         this.reply(m.chat, `*You have stopped the chat.*`, m)
         
         let other = room.a === m.sender ? room.b : room.a
         if (other) this.reply(other, `*Your partner has stopped the chat.*\nType ${usedPrefix}start to find a new partner.`, null)
         
         // Record the match for cooldown (only if they were actually connected)
         if (room.state === 'CHATTING' && other) {
            recordMatch(m.sender, other, db.matchHistory)
         }
         
         // Remove room from database
         delete db.rooms[roomId]
         
         // Clear preferred gender on stop
         if (db.filters[m.sender]) {
            delete db.filters[m.sender].preferred
         }
         
         saveDB(db)
         break
      }
      
      case 'search':
      case 'start': {
         // Check if user has set their gender
         if (!db.userGender[m.sender]) {
            return m.reply(`*You must set your gender first!*\n\nUse: ${usedPrefix}setgender <male/female>`)
         }
         
         // Check if already in a chat
         let existingRoom = Object.keys(db.rooms).find(id => {
            const room = db.rooms[id]
            return room.a === m.sender || room.b === m.sender
         })
         
         if (existingRoom) {
            return m.reply(`*You are still in anonymous chat.*`)
         }
         
         // Parse gender preference if provided
         let preferredGender = args[0]?.toLowerCase()
         if (preferredGender && !['male', 'female'].includes(preferredGender)) {
            return m.reply(`*Invalid gender preference!*\n\nUsage: ${usedPrefix}start [male/female]\n\nExample:\n${usedPrefix}start - Find any partner\n${usedPrefix}start female - Find female partner only`)
         }
         
         // Store preferred gender in filters
         if (!db.filters[m.sender]) {
            db.filters[m.sender] = {}
         }
         if (preferredGender) {
            db.filters[m.sender].preferred = preferredGender
         } else {
            delete db.filters[m.sender].preferred
         }
         
         // Find matching room
         let matchingRoomId = Object.keys(db.rooms).find(id => {
            const room = db.rooms[id]
            if (room.state !== 'WAITING' || room.a === m.sender) return false
            
            // Check if cooldown period has passed
            if (!canMatch(m.sender, room.a, db.matchHistory)) return false
            
            // Check gender compatibility
            const waitingUserGender = db.userGender[room.a]
            const searchingUserGender = db.userGender[m.sender]
            
            // Check if waiting user has preference
            const waitingUserFilters = db.filters[room.a]
            if (waitingUserFilters?.preferred) {
               if (waitingUserFilters.preferred !== searchingUserGender) return false
            }
            
            // Check if searching user has preference
            const searchingUserFilters = db.filters[m.sender]
            if (searchingUserFilters?.preferred) {
               if (searchingUserFilters.preferred !== waitingUserGender) return false
            }
            
            return true
         })
         
         if (matchingRoomId) {
            // Match found
            let room = db.rooms[matchingRoomId]
            const partnerGender = db.userGender[room.a]
            const yourGender = db.userGender[m.sender]
            
            this.reply(room.a, `*Partner found!*\n👤 Gender: ${yourGender}`, null)
            room.b = m.sender
            room.state = 'CHATTING'
            this.reply(room.b, `*Partner found!*\n👤 Gender: ${partnerGender}`, null)
         } else {
            // Create new room
            let id = Date.now().toString()
            db.rooms[id] = {
               id,
               a: m.sender,
               b: '',
               state: 'WAITING',
               createdAt: new Date().toISOString()
            }
            
            const searchMsg = preferredGender 
               ? `*Waiting for a ${preferredGender} partner...*` 
               : `*Waiting for a partner...*`
            m.reply(searchMsg)
         }
         
         saveDB(db)
         break
      }
   }
}

// Helper functions for room operations
function checkRoom(room, who) {
   return room.a === who || room.b === who
}

function getOther(room, who) {
   return who === room.a ? room.b : who === room.b ? room.a : ''
}

handler.help = ['start', 'skip', 'stop', 'next', 'search', 'setgender', 'status', 'stats', 'statistic']
handler.command = ['start', 'skip', 'stop', 'next', 'search', 'setgender', 'status', 'stats', 'statistic']
handler.tags = ['anonymous']
handler.private = true
module.exports = handler